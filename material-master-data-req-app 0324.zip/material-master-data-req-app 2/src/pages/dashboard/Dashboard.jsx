import React, { useState } from 'react'
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import StatusCard from '../../components/dashboard/StatusCard';
import { REQUEST_STATUSES, REQUEST_DATA } from '../../test-data/dashboard-test';



function DashboardPage() {

  const [requestData, setRequestData] = useState();

  function handleFilterClick(status) {
    console.log(status);

    if (status === 'OPEN') {
      const openData = REQUEST_DATA.filter( data => data.currentState === 'Incomplete' || data.currentState === 'Waiting On Approval');
      setRequestData(openData);
    }
  }

  return (
    <div className="container min-h-screen bg-gradient-to-br from-purple-100 to-indigo-200 p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-2xl p-8">
        <h1 className="text-4xl font-bold text-indigo-800 mb-8">
          Dashboard
        </h1>
        <div className='row'>
          {REQUEST_STATUSES.map((status) => (
             <StatusCard 
             cardHeader={status.cardHeader} 
             cardTitle={status.cardTitle} 
             cardText={status.cardText} 
             cardButtonText={status.cardButtonText}
             status={status.status}
             handleFilterClick={handleFilterClick}
             />
          ))}
        </div>
        <br />
        <br /><br />
        <div className="row">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>Request Id</th>
                <th>Workflow</th>
                <th>Request Name</th>
                <th>Current State</th>
                <th>Created On</th>
                <th>Created By</th>
                <th>Last Updated on</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {requestData && requestData.map((data) => (
                <tr key={data.requestId}>
                  <td key={data.requestId}>{data.requestId}</td>
                  <td>{data.workflow}</td>
                  <td>{data.requestName}</td>
                  <td>{data.currentState}</td>
                  <td>{data.createdOn}</td>
                  <td>{data.createdBy}</td>
                  <td>{data.lastUpdatedOn}</td>
                  <td>action</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default DashboardPage