import React from 'react'
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import BasicDataForm from '../../components/basic-data/BasicDataForm';

function NewMaterialRequestPage() {
  return (
    <div className="container min-h-screen bg-gradient-to-br from-purple-100 to-indigo-200 p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-2xl p-8">
        <h1 className="text-4xl font-bold text-indigo-800 mb-8">
          Create New Product
        </h1>
      </div>
      <form>
        <BasicDataForm />
        {/* <SalesOrganizationData />
        <PlantDataForm /> */}
      </form>
    </div>
  )
}

export default NewMaterialRequestPage