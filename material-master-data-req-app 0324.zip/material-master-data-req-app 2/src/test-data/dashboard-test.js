export const REQUEST_STATUSES = [
    {
      cardHeader: 'Open Request',
      cardTitle: 'You have 6 open request.',  
      cardText: 'Open request consist of Incomplete and Waiting on Approval request.', 
      cardButtonText: 'Show Open Request', 
      numberOfRequest: 6, 
      status: 'OPEN'
    },
    {
      cardHeader: 'Closed Request', 
      cardTitle: 'You have 6 closed request ', 
      cardText: 'Closed request include completed and cancelled request.', 
      cardButtonText: 'Show Closed Request', 
      numberOfRequest: 6, 
      status: 'CLOSED'
    }
    // 'In-Progress',  // user has not submitted request
    // 'Waiting for Approval', // user submitted but waiting on approval
    // 'Completed', // approval granted material created, updated, or extended
    // 'Cancelled' // user cancelled request
  ]

  export const REQUEST_DATA = [
    {
        requestId: 200001,
        workflow: 'Material-Request',
        requestName: 'New Material',
        currentState: 'Incomplete',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200002,
        workflow: 'Material-Request',
        requestName: 'New Material',
        currentState: 'Waiting On Approval',
        createdOn: '03/25/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200003,
        workflow: 'Material-Request',
        requestName: 'Extend Material',
        currentState: 'Waiting On Approval',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200004,
        workflow: 'Material-Request',
        requestName: 'Extend Material',
        currentState: 'Waiting On Approval',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200010,
        workflow: 'Material-Request',
        requestName: 'New Material',
        currentState: 'Incomplete',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200012,
        workflow: 'Material-Request',
        requestName: 'Extend Material',
        currentState: 'Waiting On Approval',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200005,
        workflow: 'Material-Request',
        requestName: 'New Material',
        currentState: 'Completed',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200006,
        workflow: 'Material-Request',
        requestName: 'New Material',
        currentState: 'Cancelled',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200007,
        workflow: 'Material-Request',
        requestName: 'Extend Material',
        currentState: 'Complete',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200008,
        workflow: 'Material-Request',
        requestName: 'New Material',
        currentState: 'Cancelled',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200009,
        workflow: 'Material-Request',
        requestName: 'Extend Material',
        currentState: 'Cancelled',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
    {
        requestId: 200011,
        workflow: 'Material-Request',
        requestName: 'New Material',
        currentState: 'Complete',
        createdOn: '03/22/2025 12:00:00 PM',
        createdBy: 'Leon.Smith@cobbvantress.com',
        lastUpdatedOn: '03/24/2025 01:01:00 PM'
    },
  ]