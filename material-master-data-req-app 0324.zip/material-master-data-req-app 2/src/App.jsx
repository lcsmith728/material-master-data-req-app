import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import RootLayout from "./pages/Root";
import DashboardPage from "./pages/dashboard/Dashboard";
import NewMaterialRequestPage from "./pages/material-request/NewMaterialRequest";
function App() {

  const router = createBrowserRouter([
    {path: '/',
      element: <RootLayout />,
      children: [
        { index: true, element: <DashboardPage />},
        { path: '/material/new-request', element: <NewMaterialRequestPage />}
      ]
    }
  ]);

  return (
    <RouterProvider router={router} />
  );
}

export default App;
