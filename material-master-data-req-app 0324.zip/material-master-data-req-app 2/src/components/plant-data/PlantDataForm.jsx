import React from "react";

function PlantDataForm() {
  return (
    <div>
      <div className="row g-3">
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Plant
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Availability Check
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Profit Center
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            MRP Type
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
      <div className="row g-3">
        <div className="col-md">
          <label htmlFor="" className="form-label">
            Storage Location
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md">
          <label htmlFor="" className="form-label">
            Reorder Point
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md">
          <label htmlFor="" className="form-label">
            Lot Sizing Procedure
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md">
          <label htmlFor="" className="form-label">
            Maximum Stock Level
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md">
          <label htmlFor="" className="form-label">
            Safety Stock
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
    </div>
  );
}

export default PlantDataForm;
