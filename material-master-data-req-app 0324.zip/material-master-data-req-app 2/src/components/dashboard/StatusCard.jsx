import React from 'react'

function StatusCard({ cardHeader, cardTitle, cardText, cardButtonText, status, handleFilterClick }) {
  return (
    <>
        <div className="col" key={1}>
            <div className="card">
              <div className="card-header">
                {cardHeader}
              </div>
              <div className="card-body">
                  <h5 className="card-title">{cardTitle}</h5>
                  <p className="card-text">{cardText}</p>
                  <a href="" className="btn btn-primary" onClick={() => handleFilterClick(status)}>{cardButtonText}</a>
              </div>
            </div>
        </div>
    </>
  )
}

export default StatusCard