import React from "react";

function SalesOrganizationData() {
  return (
    <div>
      <div className="row g-3">
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Sales Organization
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-2">
          <label htmlFor="" className="form-label">
            Distribution Center
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-2">
          <div className="form-check">
            <input type="checkbox" className="form-check-input" />
            <label htmlFor="" className="form-check-label">
              Cash Discount
            </label>
          </div>
        </div>
        <div className="col-md-2">
          <label htmlFor="" className="form-label">
            Account Assmt Group Mat.
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Item Category Group
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
      <div className="row g-3">
        <div className="col-md-4">
          <label htmlFor="" className="form-label">
            Country
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-4">
          <label htmlFor="" className="form-label">
            Tax Category
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-4">
          <label htmlFor="" className="form-label">
            Tax Classification
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
      <div className="row g-3">
        <div className="col-md-6">
          <label htmlFor="" className="form-label">
            Language
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-6">
          <label htmlFor="" className="form-label">
            Sales Text
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
    </div>
  );
}

export default SalesOrganizationData;
