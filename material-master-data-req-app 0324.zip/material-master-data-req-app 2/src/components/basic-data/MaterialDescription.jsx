import React from 'react'

function MaterialDescription() {
  return (
    <div>MaterialDescription</div>
  )
}

export default MaterialDescription