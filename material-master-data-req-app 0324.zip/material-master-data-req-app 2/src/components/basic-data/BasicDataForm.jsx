import React from "react";
import './BasicDataForm.css';

function BasicDataForm() {
  return (
    <div>
      <div className="row g-3 bd-first-row">
        <div className="col-md-6">
          <label htmlFor="materialDescription" className="form-label">
            Material Description
          </label>
          <input name="materialDescription" 
            type="text" 
            className="form-control" 
           
            />
        </div>
        <div className="col-md-6">
          <label htmlFor="language" className="form-label">
            Language
          </label>
          <select name="language" id="" className="form-select">
            <option value="0" selected>
              Select a Language
            </option>
            <option value="EN">English</option>
            <option value="PT">Portuguese</option>
          </select>
        </div>

        <div>
          <table className="table">
            <thead className="table-light">
              <tr>
                <th>Description</th>
                <th>Language</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><input name="materialDescription" type="text" className="form-control" /></td>
                <td>
                  <select name="language" id="" className="form-select">
                    <option value="0" selected>
                      Select a Language
                    </option>
                    <option value="EN">English</option>
                    <option value="PT">Portuguese</option>
                  </select>
                </td>
                <td>
                  <div className="row">
                    <button className="btn btn-primary btn-sm col" >Add Alternative Text</button>
                    <button className="btn btn-secondary btn-sm col" >Save</button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="col-auto">
          <button className="btn btn-danger" >Add Alternative Text</button>
        </div>
      </div>
      <div className="row g-3 bd-form-row-spacing">
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Material Type
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-6">
          <label htmlFor="" className="form-label">
            Material Group
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Base Unit of Measure (UOM)
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
      <div className="row g-3 bd-form-row-spacing">
        <div className="col-md-2">
          <label htmlFor="" className="form-label">
            Generation
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-2">
          <label htmlFor="" className="form-label">
            Line
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-2">
          <label htmlFor="" className="form-label">
            Sex
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-4">
          <label htmlFor="" className="form-label">
            Type
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-2">
          <label htmlFor="" className="form-label">
            Chick/Egg
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
      <div className="row g-3 bd-form-row-spacing">
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Current UOM
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Alternative Unit of Measure
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Numerator for Conversion
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-3">
          <label htmlFor="" className="form-label">
            Denominator for Conversion
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
      <div className="row g-3">
        <div className="col-md-5">
          <label htmlFor="" className="form-label">
            Net Weight
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-5">
          <label htmlFor="" className="form-label">
            Gross Weight
          </label>
          <input type="text" className="form-control" />
        </div>
        <div className="col-md-2">
          <label htmlFor="" className="form-label">
            Weight UoM
          </label>
          <input type="text" className="form-control" />
        </div>
      </div>
    </div>
  );
}

export default BasicDataForm;
